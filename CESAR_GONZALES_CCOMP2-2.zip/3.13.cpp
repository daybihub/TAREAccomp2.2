#include <iostream>
#include "Account.h"

using namespace std;

void displayAccount(Account accountToDisplay) {
  cout << accountToDisplay.getName() << " balance is $" << accountToDisplay.getBalance() << endl;
}

int main() {

  // create Account objects
  Account account1("John Doe", 1000);
  Account account2("Jane Doe", 500);

  // display initial balance of each object
  displayAccount(account1);
  displayAccount(account2);

  // prompt user for deposit amount for account1
  cout << "\n\nEnter deposit amount for account1: ";
  int depositAmount;
  cin >> depositAmount;
  cout << "adding " << depositAmount << " to account1 balance";

  // deposit amount into account1
  account1.deposit(depositAmount);

  // display balances
  displayAccount(account1);
  displayAccount(account2);

  // prompt user for deposit amount for account2
  cout << "\n\nEnter deposit amount for account2: ";
  cin >> depositAmount;
  cout << "adding " << depositAmount << " to account2 balance";

  // deposit amount into account2
  account2.deposit(depositAmount);

  // display balances
  displayAccount(account1);
  displayAccount(account2);

}