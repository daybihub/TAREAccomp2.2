#include <iostream>

using namespace std;

class MotorVehicle {
public:
  string make;
  string fuelType;
  int yearOfManufacture;
  string color;
  int engineCapacity;

  MotorVehicle(string make, string fuelType, int yearOfManufacture, string color, int engineCapacity) {
    this->make = make;
    this->fuelType = fuelType;
    this->yearOfManufacture = yearOfManufacture;
    this->color = color;
    this->engineCapacity = engineCapacity;
  }

  string getMake() {
    return this->make;
  }

  string getFuelType() {
    return this->fuelType;
  }

  int getYearOfManufacture() {
    return this->yearOfManufacture;
  }

  string getColor() {
    return this->color;
  }

  int getEngineCapacity() {
    return this->engineCapacity;
  }

  void displayCarDetails() {
    cout << "Make: " << this->make << endl;
    cout << "Fuel type: " << this->fuelType << endl;
    cout << "Year of manufacture: " << this->yearOfManufacture << endl;
    cout << "Color: " << this->color << endl;
    cout << "Engine capacity: " << this->engineCapacity << endl;
  }
};

int main() {
  MotorVehicle car("Toyota", "Petrol", 2023, "Red", 1500);

  cout << car.getMake() << endl;
  cout << car.getFuelType() << endl;
  cout << car.getYearOfManufacture() << endl;
  cout << car.getColor() << endl;
  cout << car.getEngineCapacity() << endl;

  return 0;
}