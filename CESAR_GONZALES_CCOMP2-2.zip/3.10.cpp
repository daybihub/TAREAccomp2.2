#include <iostream>
#include <string>

using namespace std;

class Invoice {
public:
  string partNumber;
  string partDescription;
  int quantity;
  int pricePerItem;
  double VATRate;
  double discountRate;

  Invoice(string partNumber, string partDescription, int quantity, int pricePerItem, double VATRate = 0.2, double discountRate = 0.0) {
    this->partNumber = partNumber;
    this->partDescription = partDescription;
    this->quantity = quantity;
    this->pricePerItem = pricePerItem;
    this->VATRate = VATRate;
    this->discountRate = discountRate;
  }

  string getPartNumber() { return this->partNumber; }

  string getPartDescription() { return this->partDescription; }

  int getQuantity() { return this->quantity; }

  int getPricePerItem() { return this->pricePerItem; }

  double getVATRate() { return this->VATRate; }

  double getDiscountRate() { return this->discountRate; }

  double getInvoiceAmount() {
    double amount = this->quantity * this->pricePerItem;
    amount *= (1 + this->VATRate);
    amount -= amount * this->discountRate;
    return amount;
  }

private:
};

int main() {

  // Create an invoice object
  Invoice invoice("123456789", "Screwdriver", 10, 10);

  // Set the VAT rate
  invoice.VATRate = 0.15;

  // Set the discount rate
  invoice.discountRate = 0.05;

  // Get the invoice amount
  double invoiceAmount = invoice.getInvoiceAmount();

  // Print the invoice amount
  cout << "The invoice amount is " << invoiceAmount << endl;

  return 0;
}