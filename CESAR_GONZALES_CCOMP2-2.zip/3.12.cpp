class Date {
public:
  int month;
  int day;
  int year;

  Date(int month, int day, int year) {
    this->month = month;
    this->day = day;
    this->year = year;

    if (month < 1 || month > 12) {
      month = 1;
    }
  }

  void set_month(int month) {
    this->month = month;

    if (month < 1 || month > 12) {
      month = 1;
    }
  }

  int get_month() {
    return month;
  }

  void set_day(int day) {
    this->day = day;
  }

  int get_day() {
    return day;
  }

  void set_year(int year) {
    this->year = year;
  }

  int get_year() {
    return year;
  }

  void display_date() {
    cout << month << "/" << day << "/" << year << endl;
  }
};

int main() {
  Date date(12, 25, 2023);

  date.set_month(1);
  cout << date.get_month() << endl;

  date.set_day(31);
  cout << date.get_day() << endl;

  date.set_year(2022);
  cout << date.get_year() << endl;

  date.display_date();

  return 0;
}